"""In-process SOS service generation, named byte records and checked dispatch."""
from collections.abc import Callable, Mapping
from contextvars import ContextVar
from dataclasses import dataclass
from threading import RLock
from types import MappingProxyType


class ServiceError(ValueError):
    def __init__(self, code, message):
        super().__init__(message)
        self.code = code


def require_text(value, field, *, allow_empty=False):
    if not isinstance(value, str) or (not value and not allow_empty):
        raise ServiceError("InvalidInput", f"{field} must be nonempty text" if not allow_empty else f"{field} must be text")
    try:
        return value.encode("utf-8", "strict")
    except UnicodeEncodeError as error:
        raise ServiceError("InvalidInput", f"{field} contains a non-scalar value") from error


def encode_text(value):
    return int.from_bytes(b"\x01" + require_text(value, "text", allow_empty=True), "big")


def decode_text(value):
    if type(value) is not int or value < 1:
        raise ServiceError("InvalidInput", "expected a positive text code")
    data = value.to_bytes((value.bit_length() + 7) // 8, "big")
    if data[0] != 1:
        raise ServiceError("InvalidInput", "missing text-code prefix")
    try:
        return data[1:].decode("utf-8", "strict")
    except UnicodeDecodeError as error:
        raise ServiceError("InvalidInput", "invalid UTF-8 in text code") from error


def frame(fields):
    data = bytearray()
    for field in fields:
        raw = require_text(field, "frame", allow_empty=True)
        data.extend(str(len(raw)).encode("ascii") + b"#" + raw)
    return bytes(data)


def read_frames(data):
    fields = []
    start = 0
    while start < len(data):
        stop = data.find(b"#", start)
        digits = data[start:stop] if stop >= 0 else b""
        if not digits.isdigit() or (len(digits) > 1 and digits[0] == 48) or len(digits) > len(str(len(data))):
            raise ServiceError("InvalidInput", "invalid frame length")
        end = stop + 1 + int(digits)
        if end > len(data):
            raise ServiceError("InvalidInput", "truncated frame")
        try:
            fields.append(data[stop + 1:end].decode("utf-8", "strict"))
        except UnicodeDecodeError as error:
            raise ServiceError("InvalidInput", "invalid UTF-8 frame") from error
        start = end
    return tuple(fields)


@dataclass(frozen=True)
class ByteRecord:
    """One-dimensional SOS record. In sos.byte@1 each cell's rank is its byte."""
    name: str
    body: bytes

    def pack(self):
        require_text(self.name, "record name")
        if type(self.body) is not bytes:
            raise ServiceError("InvalidInput", "record body must be bytes")
        fields = (self.name, "sos.byte@1", "1", str(len(self.body)), *map(str, self.body))
        return int.from_bytes(b"\x01" + frame(fields), "big")

    @classmethod
    def unpack(cls, packed):
        fields = read_frames(decode_text(packed).encode("utf-8"))
        if len(fields) < 4 or fields[1:3] != ("sos.byte@1", "1") or fields[3] != str(len(fields) - 4):
            raise ServiceError("InvalidInput", "invalid byte-record profile or shape")
        require_text(fields[0], "record name")
        cells = bytearray()
        for value in fields[4:]:
            if value not in BYTE_VALUES:
                raise ServiceError("InvalidInput", "invalid canonical byte multiplicity")
            cells.append(BYTE_VALUES[value])
        return cls(fields[0], bytes(cells))


BYTE_VALUES = MappingProxyType({str(i): i for i in range(256)})


@dataclass(frozen=True)
class Registry:
    """Persistent finite grid. Register at its first unused position."""
    capacity: int
    index: Mapping
    slots: tuple

    @classmethod
    def empty(cls, capacity):
        if type(capacity) is not int or capacity < 0:
            raise ServiceError("InvalidInput", "capacity must be a nonnegative integer")
        return cls(capacity, MappingProxyType({}), ())

    def register(self, record):
        packed = record.pack()
        if record.name in self.index:
            raise ServiceError("DuplicateName", f"already registered: {record.name}")
        position = len(self.slots)
        if position == self.capacity:
            raise ServiceError("RegistryFull", "no free registry position")
        index = dict(self.index)
        index[record.name] = position
        return Registry(self.capacity, MappingProxyType(index), self.slots + (packed,))

    def lookup(self, name):
        require_text(name, "name")
        if name not in self.index:
            raise ServiceError("UnknownName", f"unknown name: {name}")
        return ByteRecord.unpack(self.slots[self.index[name]])

    def status(self, name, complete):
        if type(complete) not in (bool, int) or complete not in (0, 1):
            raise ServiceError("InvalidInput", "complete must be Boolean")
        return self.lookup(name).name, 1 - complete


def check_id(service_id):
    require_text(service_id, "service ID")
    base, sep, version = service_id.rpartition("@")
    if not base or not sep or not version.isascii() or not version.isdecimal() or version[0] == "0":
        raise ServiceError("InvalidInput", "expected a name and canonical positive @version")


@dataclass(frozen=True)
class Service:
    kind: str
    uses: frozenset
    handler: Callable


_active = ContextVar("sos_service_invocation", default=None)


class Kernel:
    """Trusted Python handlers receive a synchronous call capability scoped to one invocation."""
    def __init__(self, capacity=256):
        self._lock = RLock()
        self._registry = Registry.empty(capacity)
        self._bindings = {}

    def generate_api(self, service_id, handler):
        return self._generate(service_id, "api", (), handler)

    def generate_service(self, service_id, kind, uses, handler):
        if kind not in ("data", "algorithm"):
            raise ServiceError("InvalidInput", "service kind must be data or algorithm")
        if not isinstance(uses, (tuple, list, set, frozenset)) or not uses:
            raise ServiceError("InvalidInput", "declare a finite nonempty collection of API IDs")
        return self._generate(service_id, kind, uses, handler)

    def _generate(self, service_id, kind, uses, handler):
        if _active.get() is not None:
            raise ServiceError("ForbiddenCall", "generation is outside a service invocation")
        check_id(service_id)
        if not callable(handler):
            raise ServiceError("InvalidInput", "expected a callable implementation")
        for target in uses:
            check_id(target)
        dependencies = frozenset(uses)
        if len(dependencies) != len(uses):
            raise ServiceError("InvalidInput", "duplicate API declaration")
        with self._lock:
            if service_id in self._bindings:
                raise ServiceError("DuplicateName", f"already registered: {service_id}")
            for target in sorted(dependencies):
                if target not in self._bindings or self._bindings[target].kind != "api":
                    raise ServiceError("InvalidDependency", f"expected a generated API: {target}")
            record = ByteRecord(service_id, frame((kind, *sorted(dependencies))))
            registry = self._registry.register(record)
            bindings = dict(self._bindings)
            bindings[service_id] = Service(kind, dependencies, handler)
            self._registry, self._bindings = registry, bindings
        return service_id

    def describe(self, service_id):
        """Return the canonical named descriptor record at this generation snapshot."""
        if _active.get() is not None:
            raise ServiceError("ForbiddenCall", "catalog inspection is outside a service invocation")
        with self._lock:
            return self._registry.lookup(service_id)

    def run(self, service_id, argument):
        if _active.get() is not None:
            raise ServiceError("ForbiddenCall", "nested dispatch must use the service capability")
        check_id(service_id)
        with self._lock:
            self._registry.lookup(service_id)
            bindings = self._bindings
        service = bindings[service_id]
        invocation = object()
        token = _active.set(invocation)
        open_call = True
        used = set()

        def call(api_id, value):
            if not open_call or _active.get() is not invocation:
                raise ServiceError("ExpiredCall", "API capability is outside its invocation")
            check_id(api_id)
            if api_id not in service.uses:
                raise ServiceError("ForbiddenCall", f"undeclared API: {api_id}")
            api_token = _active.set(object())
            try:
                result = bindings[api_id].handler(value)
            finally:
                _active.reset(api_token)
            used.add(api_id)
            return result

        try:
            if service.kind == "api":
                return service.handler(argument)
            result = service.handler(call, argument)
            if used != service.uses:
                raise ServiceError("IncompleteUse", "unused APIs: " + ", ".join(sorted(service.uses - used)))
            return result
        except ServiceError:
            raise
        except Exception as error:
            raise ServiceError("ServiceFailure", f"handler raised {type(error).__name__}") from error
        finally:
            open_call = False
            _active.reset(token)
