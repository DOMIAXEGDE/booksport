"""Read a finite claim set using the generated SOS reading services."""
import json
import sys
from dataclasses import dataclass
from pathlib import Path

from kernel_services import ByteRecord, Kernel, Registry, ServiceError, frame, read_frames, require_text


OPEN = "api.read.open@1"
ADVANCE = "api.read.advance@1"
REPORT = "api.read.report@1"
DATA = "data.read.state@1"
ALGORITHM = "algorithm.read@1"


@dataclass(frozen=True)
class Claim:
    name: str
    text: str
    terms: tuple


@dataclass(frozen=True)
class ReadingState:
    claims: tuple
    records: Registry


def open_batch(payload):
    if type(payload) is not dict or set(payload) != {"claims"} or type(payload["claims"]) is not list:
        raise ServiceError("InvalidInput", "expected an object containing only the claims array")
    claims = []
    names = set()
    for position, entry in enumerate(payload["claims"]):
        prefix = f"claims[{position}]"
        if type(entry) is not dict or set(entry) != {"id", "text", "terms"}:
            raise ServiceError("InvalidInput", f"{prefix} must contain only id, text, and terms")
        name, text, terms = entry["id"], entry["text"], entry["terms"]
        require_text(name, prefix + ".id")
        require_text(text, prefix + ".text")
        if name in names:
            raise ServiceError("InvalidInput", f"{prefix}.id is already present")
        if type(terms) is not list or len(terms) not in (2, 3, 5):
            raise ServiceError("InvalidInput", f"{prefix}.terms must contain exactly 2, 3, or 5 strings")
        for axis, term in enumerate(terms):
            require_text(term, f"{prefix}.terms[{axis}]")
        names.add(name)
        claims.append(Claim(name, text, tuple(terms)))
    return ReadingState(tuple(claims), Registry.empty(len(claims)))


def advance(state):
    """An exhaustion probe returns unchanged state and False; a commit returns True."""
    if type(state) is not ReadingState:
        raise ServiceError("InvalidInput", "advance requires an opened reading state")
    position = len(state.records.slots)
    if position == len(state.claims):
        return state, False
    claim = state.claims[position]
    relation = ByteRecord(claim.name, frame((claim.text, *claim.terms)))
    records = state.records.register(relation)
    return ReadingState(state.claims, records), True


def report(state):
    if type(state) is not ReadingState:
        raise ServiceError("InvalidInput", "report requires an opened reading state")
    if len(state.records.slots) != len(state.claims):
        raise ServiceError("IncompleteReading", "unread claims remain")
    relations = []
    for claim in state.claims:
        record = state.records.lookup(claim.name)
        text, *terms = read_frames(record.body)
        relations.append({"id": record.name, "text": text, "arity": len(terms), "terms": terms})
    return {"status": 0, "unread": 0, "relations": relations}


def read_claims(call, payload):
    state = call(OPEN, payload)
    while True:
        state, consumed = call(ADVANCE, state)
        if not consumed:
            return call(REPORT, state)


def make_kernel():
    kernel = Kernel()
    kernel.generate_api(OPEN, open_batch)
    kernel.generate_api(ADVANCE, advance)
    kernel.generate_api(REPORT, report)
    kernel.generate_service(DATA, "data", (OPEN,), lambda call, payload: call(OPEN, payload))
    kernel.generate_service(ALGORITHM, "algorithm", (OPEN, ADVANCE, REPORT), read_claims)
    return kernel


def json_object(pairs):
    obj = {}
    for key, value in pairs:
        if key in obj:
            raise ServiceError("InvalidInput", f"duplicate JSON key: {key}")
        obj[key] = value
    return obj


def main(argv):
    try:
        if len(argv) > 1:
            raise ServiceError("InvalidInput", "usage: reading_service.py [input.json]")
        raw = Path(argv[0]).read_bytes() if argv else sys.stdin.buffer.read()
        payload = json.loads(raw.decode("utf-8"), object_pairs_hook=json_object)
        result = make_kernel().run(ALGORITHM, payload)
    except (ServiceError, ValueError, OSError, RecursionError) as error:
        code = error.code if isinstance(error, ServiceError) else "InvalidInput"
        print(json.dumps({"error": code, "message": str(error)}, ensure_ascii=True), file=sys.stderr)
        return 2
    print(json.dumps(result, ensure_ascii=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
